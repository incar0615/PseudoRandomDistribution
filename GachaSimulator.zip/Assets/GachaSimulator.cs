﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class GachaSimulator : MonoBehaviour {

    public float UR_prob;
    public float SR_prob;
    public float R_prob;

    public int gachaCnt;
    public int sumTryCnt;
    public int findTryCnt;

    public float urd_failCnt;
    public float failCnt;

    public int urdTopFailCnt, prdTopFailCnt;
    public float factor;

    public Text PRD_ur_cntText;
    public Text PRD_sr_cntText;
    public Text PRD_r_cntText;

    public Text URD_ur_cntText;
    public Text URD_sr_cntText;
    public Text URD_r_cntText;

    public Text FactorValue;
    public Text GachaCntText;

    public Text URD_FailText;
    public Text PRD_FailText;
    public GameObject loadImage;
    public Text loadText;
    int PRD_ur_cnt;
    int PRD_sr_cnt;
    int PRD_r_cnt;

    int URD_ur_cnt;
    int URD_sr_cnt;
    int URD_r_cnt;

    float loadPercentage;
    private string txtFieldString = "5성 확률 입력";
    // Use this for initialization
    
    void OnGUI()
    {
        txtFieldString = GUI.TextField(new Rect(Screen.width * 0.15f, Screen.height *0.5f, Screen.width * 0.15f, Screen.height * 0.04f), txtFieldString);
        
        if (float.TryParse(txtFieldString,out UR_prob)){
        }
    }

    public void FindFactorMultiButton(bool _bool)
    {
      
        loadImage.SetActive(true);
        Init();
        if (_bool)
        {
            StartCoroutine(FindFactor_Multi(UR_prob * 0.01f, UR_prob * 0.01f, 0));
        }
        FactorValue.text = (UR_prob * Mathf.Pow(1.0f + factor,failCnt)).ToString() + "%";
    }
    void Start () {
	    
	}

    void CustomRandom_Multi(float _prob, float _factor)
    {
        double rValue = 0;
       
        rValue = _prob*100 /(1/_prob);

        for (int i = 1; i < 1001; i++)
        {
            float randNum = Random.Range(0.0f, 100.0f);

            if (randNum < rValue)
            {
                findTryCnt += i;
                return;
            }
            rValue += _factor;
            //rValue *= (1 + _factor);
            //factor += _prob * _factor;
        }
    }
    

    IEnumerator FindFactor_Multi(float _prob, float _factor, int _enforceCnt)
    {
        findTryCnt = 0;
        
        if (_enforceCnt > 100)
        {
            loadImage.SetActive(false);
            factor = _factor;
            StopAllCoroutines();
        }
        for (int i = 0; i < 200; i++)
        {
            //CustomRandom_Plus(_prob, factor);
            CustomRandom_Multi(_prob, _factor);
            yield return new WaitForEndOfFrame();
          
        }
        loadText.text = "확률 계산 중 ......" + _enforceCnt.ToString();
        yield return new WaitForEndOfFrame();
        
        if ((findTryCnt / 200.0f) <= (1.0f / _prob) * 1.05f && (findTryCnt / 200.0f) >= (1.0f / _prob) * 0.95f)
       {
            loadImage.SetActive(false);
            factor = _factor;
       }
       else if ((findTryCnt / 200.0f) > (1.0f / _prob) * 0.95f)
       {
            StartCoroutine(FindFactor_Multi(_prob, _factor * 1.3f, _enforceCnt + 1));
       }
       else if ((findTryCnt / 200.0f) < (1.0f / _prob) * 1.05f)
       {
            StartCoroutine(FindFactor_Multi(_prob, _factor * 0.70f, _enforceCnt + 1));
       }
    }
    public void QuitCalc()
    {
        StopAllCoroutines();
        Init();
        loadImage.SetActive(false);
    }
    public void Init()
    {
        failCnt = 0;
        urd_failCnt = 0;
        sumTryCnt = 0;
        findTryCnt = 0;
        gachaCnt = 0;
        PRD_ur_cnt = 0;
        PRD_sr_cnt = 0;
        PRD_r_cnt = 0;
        URD_ur_cnt = 0;
        URD_sr_cnt = 0;
        URD_r_cnt = 0;
        prdTopFailCnt = 0;
        urdTopFailCnt = 0;

        SR_prob = 10.0f + UR_prob;
        renewCntText();
    }
	
    void renewCntText()
    {
        if(gachaCnt == 0)
        {
            PRD_ur_cntText.text = PRD_ur_cnt.ToString();
            PRD_sr_cntText.text = PRD_sr_cnt.ToString();
            PRD_r_cntText.text = PRD_r_cnt.ToString();

            URD_ur_cntText.text = URD_ur_cnt.ToString();
            URD_sr_cntText.text = URD_sr_cnt.ToString();
            URD_r_cntText.text = URD_r_cnt.ToString();

          
        }
       else
        {
            PRD_ur_cntText.text = PRD_ur_cnt.ToString() + " (" + ((float)PRD_ur_cnt / (float)gachaCnt * 100).ToString() + "%)";
            PRD_sr_cntText.text = PRD_sr_cnt.ToString() + " (" + ((float)PRD_sr_cnt / (float)gachaCnt * 100).ToString() + "%)";
            PRD_r_cntText.text = PRD_r_cnt.ToString() + " (" + ((float)PRD_r_cnt / (float)gachaCnt * 100).ToString() + "%)";

            URD_ur_cntText.text = URD_ur_cnt.ToString() + " (" + ((float)URD_ur_cnt / (float)gachaCnt * 100).ToString() + "%)";
            URD_sr_cntText.text = URD_sr_cnt.ToString() + " (" + ((float)URD_sr_cnt / (float)gachaCnt * 100).ToString() + "%)";
            URD_r_cntText.text = URD_r_cnt.ToString() + " (" + ((float)URD_r_cnt / (float)gachaCnt * 100).ToString() + "%)";
            
        }
        URD_FailText.text = "최고연속실패 = " + urdTopFailCnt.ToString();
        PRD_FailText.text = "최고연속실패 = " + prdTopFailCnt.ToString();
        GachaCntText.text = gachaCnt.ToString();
        FactorValue.text = (UR_prob / (100 / UR_prob) + (factor * failCnt)) + "%";
    }
	// Update is called once per frame
	void Update () {
	    
	}
  
    public void ButtonClicked(int _num)
    {
        gachaCnt += _num;
        Try_PRD(_num);
        Try_URD(_num);

        renewCntText();
    }

    void Try_URD(int _num)
    {
        for(int i=0; i<_num; i++)
        {
            float rand = Random.Range(0.0f, 100.0f);

            if(rand < UR_prob)
            {
                URD_ur_cnt++;
                urd_failCnt =0;
            }
            else if(rand < SR_prob)
            {
                URD_sr_cnt++;
                urd_failCnt++;
                if(urd_failCnt > urdTopFailCnt)
                {
                    urdTopFailCnt = (int)urd_failCnt;
                }
            }
            else
            {
               URD_r_cnt++;
               urd_failCnt++;
                if (urd_failCnt > urdTopFailCnt)
                {
                    urdTopFailCnt = (int)urd_failCnt;
                }
            }

        }
    }

    void Try_PRD(int _num)
    {
        for (int i = 0; i < _num; i++)
        {
            
            float rand = Random.Range(0.0f, 100.0f);
            //_prob / (1 / _prob)
            if (rand < (UR_prob / (100/UR_prob) + (factor * failCnt)))
            {
                PRD_ur_cnt++;
                failCnt = 0;
            }
            else if (rand < SR_prob)
            {
                PRD_sr_cnt++;
                failCnt++;
                if (failCnt > prdTopFailCnt)
                {
                    prdTopFailCnt = (int)failCnt;
                }
            }
            else
            {
                PRD_r_cnt++;
                failCnt++;
                if (failCnt > prdTopFailCnt)
                {
                    prdTopFailCnt = (int)failCnt;
                }
            }

        }
    }
}
